# MLCSwift

This is a simple swift package that exposes the chat module to swift.
Checkout our [documentation](https://llm.mlc.ai/docs/) for more examples.
