# MLC Chat App

Checkout [Documentation page](https://llm.mlc.ai/docs/deploy/ios.html) for more information.

- run `mlc_llm package`
- open the Xcode project
