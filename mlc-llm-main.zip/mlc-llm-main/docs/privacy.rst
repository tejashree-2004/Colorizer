MLC Chat App Privacy
====================

MLC Chat run all generation locally.
All data stays in users' device and is not collected by the app.
