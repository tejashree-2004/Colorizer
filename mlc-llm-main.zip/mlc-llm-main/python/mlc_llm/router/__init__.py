"""Subdirectory of router, which routes to multiple engine endpoints."""

from .. import base
from .router import Router
