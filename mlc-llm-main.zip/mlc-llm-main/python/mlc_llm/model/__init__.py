"""Model definition for the compiler."""

from .model import MODELS, Model
from .model_preset import MODEL_PRESETS
